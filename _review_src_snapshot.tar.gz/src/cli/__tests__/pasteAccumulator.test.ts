import { describe, it, expect } from 'vitest'
import { PasteAccumulator } from '../pasteAccumulator.js'

const PASTE_START = '\x1b[200~'
const PASTE_END = '\x1b[201~'

/**
 * Simulate a bracketed paste: the terminal wraps the content in 200~/201~
 * markers and delivers it as one chunk; readline fires a 'line' for each
 * embedded newline and buffers the tail (which holds the closing marker).
 */
function bracketPaste(acc: PasteAccumulator, content: string): Array<string | null> {
  const chunk = PASTE_START + content + PASTE_END
  acc.onData(chunk)
  const completed = chunk.split('\n').slice(0, -1)
  return completed.map(line => acc.onLine(line))
}

/**
 * Helpers model how a terminal + readline feed the accumulator:
 *   - typing a line, then pressing Enter, arrives as a text chunk (no 'line'
 *     event yet) followed by a bare "\r" chunk that DOES fire 'line'.
 *   - a paste arrives as a single chunk whose embedded "\n" bytes each fire a
 *     'line' event, all classified against that same (non-bare) chunk.
 */

/** Simulate the user typing `text` then pressing Enter. Returns submit|null. */
function typeLine(acc: PasteAccumulator, text: string): string | null {
  // Keystrokes (no newline) don't fire 'line'; only record the Enter chunk.
  acc.onData('\r')
  return acc.onLine(text)
}

/**
 * Simulate pasting `chunk` (raw bytes incl. embedded newlines). Mirrors the
 * CLI wiring: onData(chunk) once, then onLine() for each line readline splits
 * out. Returns the array of per-line results (null = accumulated).
 */
function paste(acc: PasteAccumulator, chunk: string): Array<string | null> {
  acc.onData(chunk)
  // readline emits a 'line' for each completed line (text terminated by \n) and
  // buffers any tail after the last \n. Splitting on \n and dropping the final
  // segment yields exactly the completed lines for both "a\nb\n" → ["a","b"]
  // and "a\nb\nc" → ["a","b"] (with "c" left buffered).
  const completed = chunk.split('\n').slice(0, -1)
  return completed.map(line => acc.onLine(line))
}

describe('PasteAccumulator', () => {
  it('reports paste chunks for display suppression without flagging ordinary Enter', () => {
    const acc = new PasteAccumulator()
    expect(acc.onData('typed')).toMatchObject({ isPaste: false, text: 'typed' })
    expect(acc.onData('\r')).toMatchObject({ isPaste: false, text: '\r' })
    expect(acc.onData(PASTE_START + 'pasted text' + PASTE_END))
      .toMatchObject({ isPaste: true, text: 'pasted text' })
  })

  it('reports markerless multiline paste chunks and split bare-newline chunks', () => {
    const acc = new PasteAccumulator()
    expect(acc.onData('L1\nL2')).toMatchObject({ isPaste: true, text: 'L1\nL2' })
    expect(acc.onLine('L1')).toBeNull()
    expect(acc.onData('\n')).toMatchObject({ isPaste: true, text: '\n' })
  })

  it('submits a single typed line on Enter', () => {
    const acc = new PasteAccumulator()
    expect(typeLine(acc, 'hello world')).toBe('hello world')
  })

  // ── Fallback coalesce window (markerless terminals) ──────────────────────
  describe('fallback coalesce window', () => {
    // A controllable fake timer so tests can decide whether the window elapses.
    function makeAcc() {
      const timers: Array<{ id: number; fn: () => void }> = []
      let next = 1
      const submits: string[] = []
      const acc = new PasteAccumulator({
        coalesceMs: 15,
        onDeferredSubmit: (m) => submits.push(m),
        schedule: (fn) => { const id = next++; timers.push({ id, fn }); return id },
        cancel: (h) => { const i = timers.findIndex(t => t.id === h); if (i >= 0) timers.splice(i, 1) },
      })
      return {
        acc, submits,
        elapse: () => { const pend = timers.splice(0); pend.forEach(t => t.fn()) },
        pending: () => timers.length,
      }
    }

    it('re-joins a paste split when a lone-newline chunk lands mid-paste', () => {
      const { acc, submits, elapse, pending } = makeAcc()
      // Markerless paste "L1\nL2" delivered, then a lone "\n" chunk (the split),
      // then "L3\nL4" — historically this flushed "L1\nL2" early.
      acc.onData('报错了：L1\nL2')
      expect(acc.onLine('报错了：L1')).toBeNull()   // buffered
      acc.onData('\n')                               // lone-newline chunk
      expect(acc.onLine('L2')).toBeNull()            // DEFERRED, not flushed
      expect(pending()).toBe(1)
      acc.onData('L3\nL4')                           // more input → cancels defer
      expect(pending()).toBe(0)
      expect(acc.onLine('L3')).toBeNull()
      // Real Enter ends it: bare chunk, empty line, content buffered → defer…
      acc.onData('\r')
      expect(acc.onLine('L4')).toBeNull()            // pushed L4
      acc.onData('\r')
      expect(acc.onLine('')).toBeNull()              // deferred final flush
      elapse()
      expect(submits).toEqual(['报错了：L1\nL2\nL3\nL4'])
    })

    it('flushes once the window elapses with no further input (real Enter)', () => {
      const { acc, submits, elapse } = makeAcc()
      acc.onData('a\nb\nc')                  // markerless paste, "c" buffered
      expect(acc.onLine('a')).toBeNull()
      expect(acc.onLine('b')).toBeNull()
      acc.onData('\r')                       // user Enter
      expect(acc.onLine('c')).toBeNull()     // deferred (prior content buffered)
      elapse()                               // window passes, nothing cancelled
      expect(submits).toEqual(['a\nb\nc'])
    })

    it('never defers a lone typed line (no prior buffered content)', () => {
      const { acc, submits } = makeAcc()
      acc.onData('\r')
      // priorLines === 0 → synchronous flush, no timer, no deferred submit.
      expect(acc.onLine('hello')).toBe('hello')
      expect(submits).toEqual([])
    })

    it('once a bracketed marker is seen, the window is disabled (no latency)', () => {
      const { acc, submits } = makeAcc()
      // A bracketed paste in this session sets markerSeen.
      acc.onData(PASTE_START + 'x\ny' + PASTE_END)
      acc.onLine('x'); acc.onLine('y')
      acc.onData('\r')
      // Bare Enter now flushes synchronously (returns the value, not deferred).
      expect(acc.onLine('')).toBe('x\ny')
      expect(submits).toEqual([])
    })
  })

  it('submits an empty line on a bare Enter', () => {
    const acc = new PasteAccumulator()
    expect(typeLine(acc, '')).toBe('')
  })

  it('does NOT auto-submit a single-line paste that ends in a newline', () => {
    const acc = new PasteAccumulator()
    // "deploy now\n" — the trailing \n is pasted, not a user Enter.
    const results = paste(acc, 'deploy now\n')
    expect(results).toEqual([null])
    // Nothing fired; only the user's explicit Enter submits it.
    expect(typeLine(acc, '')).toBe('deploy now')
  })

  it('does NOT auto-submit a multi-line paste ending in newline', () => {
    const acc = new PasteAccumulator()
    const results = paste(acc, 'a\nb\nc\n')
    expect(results).toEqual([null, null, null])
    // Explicit Enter flushes the whole block as ONE message.
    expect(typeLine(acc, '')).toBe('a\nb\nc')
  })

  it('merges paste-then-typed-tail into a single submission (the reported bug)', () => {
    const acc = new PasteAccumulator()
    // User pastes "a\nb\nc\n", pauses, then types "d" and presses Enter.
    expect(paste(acc, 'a\nb\nc\n')).toEqual([null, null, null])
    // Typing "d" then Enter — must NOT produce a second message; it joins.
    expect(typeLine(acc, 'd')).toBe('a\nb\nc\nd')
  })

  it('handles a paste with no trailing newline then a typed tail', () => {
    const acc = new PasteAccumulator()
    // "a\nb\nc" — readline emits "a","b" and buffers "c".
    expect(paste(acc, 'a\nb\nc')).toEqual([null, null])
    // User keeps typing on the buffered "c" line → "cd", then Enter.
    expect(typeLine(acc, 'cd')).toBe('a\nb\ncd')
  })

  it('clear() drops accumulated lines (Ctrl+C drain)', () => {
    const acc = new PasteAccumulator()
    paste(acc, 'a\nb\nc\n')
    acc.clear()
    // After clearing, a fresh Enter submits only what comes next.
    expect(typeLine(acc, 'fresh')).toBe('fresh')
  })

  it('drain() recovers a buffered paste at EOF, else returns null', () => {
    const acc = new PasteAccumulator()
    expect(acc.drain()).toBeNull()
    paste(acc, 'x\ny\n')
    expect(acc.drain()).toBe('x\ny')
    // Drained buffer is now empty.
    expect(acc.drain()).toBeNull()
  })

  it('resetChunk() prevents a stale chunk from being read as a bare Enter', () => {
    const acc = new PasteAccumulator()
    // Pretend a bare Enter arrived but was swallowed by the SIGINT drain window.
    acc.onData('\r')
    acc.resetChunk()
    // A line firing now must NOT be treated as a submit (stale chunk cleared).
    expect(acc.onLine('partial')).toBeNull()
  })

  it('treats a standalone CRLF chunk as a submit', () => {
    const acc = new PasteAccumulator()
    acc.onData('\r\n')
    expect(acc.onLine('typed')).toBe('typed')
  })

  // ── Bracketed paste mode (precise classification) ────────────────────────

  it('accumulates a bracketed multi-line paste and flushes on explicit Enter', () => {
    const acc = new PasteAccumulator()
    // Markers guarantee these newlines are pasted, not typed.
    expect(bracketPaste(acc, 'a\nb\nc\n')).toEqual([null, null, null])
    expect(typeLine(acc, '')).toBe('a\nb\nc')
  })

  it('bracketed paste with no trailing newline keeps the tail for the Enter', () => {
    const acc = new PasteAccumulator()
    // "a\nb\nc" → readline emits "a","b"; "c"+closing-marker stay buffered.
    expect(bracketPaste(acc, 'a\nb\nc')).toEqual([null, null])
    // The user's Enter fires the buffered tail line "c".
    expect(typeLine(acc, 'c')).toBe('a\nb\nc')
  })

  it('merges a bracketed paste with a later typed tail (the reported bug)', () => {
    const acc = new PasteAccumulator()
    expect(bracketPaste(acc, 'a\nb\nc\n')).toEqual([null, null, null])
    // Even after an arbitrary pause, typing "d" + Enter joins — no timer race.
    expect(typeLine(acc, 'd')).toBe('a\nb\nc\nd')
  })

  it('handles bracketed markers split across separate chunks', () => {
    const acc = new PasteAccumulator()
    acc.onData(PASTE_START)            // opening marker alone
    acc.onData('a\nb\nc')              // content arrives next (paste still open)
    expect(acc.onLine('a')).toBeNull()
    expect(acc.onLine('b')).toBeNull()
    acc.onData(PASTE_END)              // closing marker alone
    // "c" was buffered by readline; the user's Enter flushes the block.
    expect(typeLine(acc, 'c')).toBe('a\nb\nc')
  })

  it('recognises a CLOSING marker split mid-sequence across chunks (the freeze bug)', () => {
    const acc = new PasteAccumulator()
    acc.onData(PASTE_START)            // paste opens
    acc.onData('a\nb\nc')              // content (paste still open)
    expect(acc.onLine('a')).toBeNull()
    expect(acc.onLine('b')).toBeNull()
    expect(acc.buffering).toBe(true)
    // Closing marker "\x1b[201~" arrives split across a stdin read boundary.
    acc.onData('\x1b[20')              // first half — must NOT be lost
    acc.onData('1~')                   // second half completes the marker
    // Paste must now be closed: a subsequent typed line submits the block.
    expect(typeLine(acc, 'c')).toBe('a\nb\nc')
    // And the accumulator is no longer stuck in buffering mode.
    expect(acc.buffering).toBe(false)
  })

  it('recognises an OPENING marker split mid-sequence across chunks', () => {
    const acc = new PasteAccumulator()
    acc.onData('\x1b[20')              // first half of opening marker
    acc.onData('0~x\ny\nz')            // completes "\x1b[200~" then content
    expect(acc.onLine('x')).toBeNull() // classified as paste, accumulated
    expect(acc.onLine('y')).toBeNull()
    acc.onData(PASTE_END)
    expect(typeLine(acc, 'z')).toBe('x\ny\nz')
  })

  it('does not over-carry a complete marker whose tail looks like a prefix', () => {
    const acc = new PasteAccumulator()
    // "\x1b[200~" ends with "\x1b[200", a prefix of the marker — must still be
    // treated as a COMPLETE opening marker, not held back as a partial.
    acc.onData(PASTE_START)
    acc.onData('hello')
    expect(acc.buffering).toBe(true)   // paste is genuinely open
    acc.onData(PASTE_END)
    expect(typeLine(acc, 'hello')).toBe('hello')
  })

  it('does not treat a newline typed after a paste closes as pasted', () => {
    const acc = new PasteAccumulator()
    expect(bracketPaste(acc, 'one\n')).toEqual([null])
    // A normal typed line afterwards must submit the whole block, not accumulate.
    expect(typeLine(acc, 'two')).toBe('one\ntwo')
  })

  it('strips paste markers that leak into a line', () => {
    const acc = new PasteAccumulator()
    acc.onData(PASTE_START + 'hello' + PASTE_END)
    // If readline hands back the marker-laden buffer, it must be cleaned out.
    expect(typeLine(acc, PASTE_START + 'hello' + PASTE_END)).toBe('hello')
  })

  // ── buffering (drives prompt suppression so a paste tail isn't redrawn with a
  //    second `you ›` prefix) ───────────────────────────────────────────────
  describe('buffering', () => {
    it('is false at rest and for a plain typed line', () => {
      const acc = new PasteAccumulator()
      expect(acc.buffering).toBe(false)
      acc.onData('\r')
      expect(acc.buffering).toBe(false)
    })

    it('is true while a multi-line paste is being collected, false after flush', () => {
      const acc = new PasteAccumulator()
      paste(acc, 'a\nb\nc')          // "a","b" emitted, "c" buffered
      expect(acc.buffering).toBe(true)
      typeLine(acc, 'cd')            // explicit Enter flushes the block
      expect(acc.buffering).toBe(false)
    })

    it('is true the instant a bracketed paste opens (before any line fires)', () => {
      const acc = new PasteAccumulator()
      acc.onData(PASTE_START + 'partial')   // open marker, content, no close yet
      expect(acc.buffering).toBe(true)
    })

    it('resets to false after clear()', () => {
      const acc = new PasteAccumulator()
      paste(acc, 'a\nb\nc\n')
      expect(acc.buffering).toBe(true)
      acc.clear()
      expect(acc.buffering).toBe(false)
    })
  })
})
