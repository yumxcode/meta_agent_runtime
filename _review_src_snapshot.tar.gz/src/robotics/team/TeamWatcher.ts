import type { TeamState, TeamStore, TeamSyncSummary, TeamTask } from './TeamStore.js'

export interface TeamWatcherEvent {
  at: string
  message: string
}

function taskKey(task: TeamTask): string {
  return `${task.id}:${task.status}:${task.ownerUnit ?? ''}:${task.attempts.length}:${task.updatedAt}`
}

function stateSignature(state: TeamState | null): string {
  if (!state) return 'null'
  return JSON.stringify({
    goals: state.goals,
    tasks: state.tasks.map(taskKey),
    units: state.units.map(u => `${u.id}:${u.status}:${u.currentTask ?? ''}:${u.lastSeen}`),
  })
}

function byId<T extends { id: string }>(items: T[]): Map<string, T> {
  return new Map(items.map(i => [i.id, i]))
}

export class TeamWatcher {
  private timer: ReturnType<typeof setInterval> | null = null
  private running = false
  private lastState: TeamState | null = null
  private lastSignature = 'uninitialized'
  private lastRemoteSignature = 'uninitialized'
  private lastSync: TeamSyncSummary | null = null
  /** ISO timestamp of when the last tick() completed successfully. */
  private lastSyncAt: string | null = null
  private events: TeamWatcherEvent[] = []

  constructor(
    private readonly store: TeamStore,
    /**
     * 5 min default: short enough that a teammate's take/note lands within a
     * coffee break, long enough to stay negligible. Actual `git fetch` traffic
     * is still bounded by TeamStore's 10-min fetch cooldown.
     */
    private readonly intervalMs = 300_000,
  ) {}

  start(): void {
    if (this.timer) return
    void this.tick()
    this.timer = setInterval(() => {
      void this.tick()
    }, this.intervalMs)
    if (this.timer.unref) this.timer.unref()
  }

  stop(): void {
    if (!this.timer) return
    clearInterval(this.timer)
    this.timer = null
  }

  /**
   * Run a single sync tick now, returning the latest TeamSyncSummary.
   *
   * `fetch` defaults to `false`: the background timer and post-operation
   * refreshes should be cheap.  Callers responding to an explicit user action
   * (e.g. `/team sync`, `/team pull`) should set it to `true`; even then the
   * cooldown inside TeamStore.sync() may skip the actual `git fetch`.
   */
  async forceSync(fetch = false): Promise<TeamSyncSummary> {
    // If a tick is already in progress, wait for it to finish (up to 5 s)
    // before starting a new one, so we never return stale data.
    let waited = 0
    while (this.running && waited < 5_000) {
      await new Promise<void>(r => setTimeout(r, 50))
      waited += 50
    }
    await this.tick(fetch)
    return this.lastSync ?? { gitFetched: false, remoteTeamChanges: [], state: this.lastState }
  }

  getRecentEvents(limit = 8): TeamWatcherEvent[] {
    return this.events.slice(-limit)
  }

  formatPromptContext(): string | null {
    const events = this.getRecentEvents()
    if (!this.lastSync && events.length === 0) return null
    const lines = ['### Team Watcher']
    if (this.lastSync) {
      lines.push(`- Last sync: ${this.lastSyncAt ?? 'pending'}`)
      if (this.lastSync.currentBranch) lines.push(`- Current branch: ${this.lastSync.currentBranch}`)
      if (this.lastSync.upstreamBranch) lines.push(`- Upstream branch: ${this.lastSync.upstreamBranch}`)
      if (typeof this.lastSync.behind === 'number' || typeof this.lastSync.ahead === 'number') {
        lines.push(`- Remote divergence: behind=${this.lastSync.behind ?? 0}, ahead=${this.lastSync.ahead ?? 0}`)
      }
      if (this.lastSync.remoteSummary) lines.push(`- Git summary: ${this.lastSync.remoteSummary.split('\n')[0]}`)
      if (this.lastSync.remoteTeamChanges.length > 0) {
        lines.push('- Remote team file changes are available after pulling:')
        this.lastSync.remoteTeamChanges.slice(0, 8).forEach(change => lines.push(`  - ${change}`))
      }
    }
    if (events.length > 0) {
      lines.push('- Recent team changes:')
      events.forEach(e => lines.push(`  - [${e.at}] ${e.message}`))
    } else {
      lines.push('- Recent team changes: none observed')
    }
    return lines.join('\n')
  }

  private async tick(forceFetch = false): Promise<void> {
    if (this.running) return
    this.running = true
    try {
      const current = await this.store.status()
      if (!current) {
        this.lastState = null
        this.lastSignature = 'null'
        return
      }

      this.lastSync = await this.store.sync({
        fetch: forceFetch,
        updatePresence: false,
      })
      this.lastSyncAt = new Date().toISOString()
      this.recordRemoteDiff(this.lastSync)

      const nextState = this.lastSync.state ?? current
      const nextSignature = stateSignature(nextState)
      if (this.lastSignature !== 'uninitialized' && nextSignature !== this.lastSignature) {
        this.recordDiff(this.lastState, nextState)
      }
      this.lastState = nextState
      this.lastSignature = nextSignature
    } catch {
      // Watcher is advisory; failures must not affect the main robotics session.
    } finally {
      this.running = false
    }
  }

  private record(message: string): void {
    // S13: in-place shift instead of slice() so we don't allocate a fresh
    // array on every tick when the buffer is at capacity.
    this.events.push({ at: new Date().toISOString(), message })
    while (this.events.length > 20) this.events.shift()
  }

  private recordRemoteDiff(sync: TeamSyncSummary): void {
    const signature = JSON.stringify({
      upstreamBranch: sync.upstreamBranch ?? '',
      ahead: sync.ahead ?? 0,
      behind: sync.behind ?? 0,
      remoteTeamChanges: sync.remoteTeamChanges,
    })
    if (this.lastRemoteSignature !== 'uninitialized' && signature !== this.lastRemoteSignature) {
      if ((sync.behind ?? 0) > 0) {
        this.record(`remote ${sync.upstreamBranch ?? 'upstream'} is ${sync.behind} commit(s) ahead of local branch`)
      }
      if (sync.remoteTeamChanges.length > 0) {
        this.record(`remote team files changed: ${sync.remoteTeamChanges.slice(0, 5).join(', ')}`)
      }
    }
    this.lastRemoteSignature = signature
  }

  private recordDiff(prev: TeamState | null, next: TeamState): void {
    if (!prev) {
      this.record('team state became available')
      return
    }

    const prevTasks = byId(prev.tasks)
    const nextTasks = byId(next.tasks)
    for (const task of next.tasks) {
      const old = prevTasks.get(task.id)
      if (!old) {
        this.record(`new task ${task.id}: ${task.title}`)
        continue
      }
      if (old.status !== task.status) {
        this.record(`${task.id} status changed ${old.status} -> ${task.status}`)
      }
      if ((old.ownerUnit ?? '') !== (task.ownerUnit ?? '')) {
        this.record(`${task.id} owner changed ${old.ownerUnit ?? 'unclaimed'} -> ${task.ownerUnit ?? 'unclaimed'}`)
      }
      if (task.attempts.length > old.attempts.length) {
        const delta = task.attempts.length - old.attempts.length
        const last = task.attempts[task.attempts.length - 1]
        this.record(`${task.id} +${delta} attempt(s)${last ? ` — ${last.unit}: ${last.direction}` : ''}`)
      }
    }
    for (const task of prev.tasks) {
      if (!nextTasks.has(task.id)) this.record(`task removed: ${task.id}`)
    }

    const prevUnits = byId(prev.units)
    for (const unit of next.units) {
      const old = prevUnits.get(unit.id)
      if (!old) {
        this.record(`unit joined: ${unit.id}`)
      } else if ((old.currentTask ?? '') !== (unit.currentTask ?? '')) {
        // currentTask is the unit's FOCUS pointer (a unit may own several
        // tasks); ownership changes are reported separately per task above.
        this.record(`unit ${unit.id} focus changed ${old.currentTask ?? 'none'} -> ${unit.currentTask ?? 'none'}`)
      }
    }
  }
}
